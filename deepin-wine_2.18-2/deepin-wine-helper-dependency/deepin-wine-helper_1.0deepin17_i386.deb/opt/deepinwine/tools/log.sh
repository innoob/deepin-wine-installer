#!/bin/bash

BOTTLE_NAME="Deepin-QQ"
DEBUG_MSG="+pid,+tid,+timestamp"
APP_PATH_MAP="Deepin-QQ=c:\Program Files\Tencent\QQ\Bin\QQ.exe
\nDeepin-QQLight=c:\Program Files\Tencent\QQLite\Bin\QQ.exe
\nDeepin-TIM=c:\Program Files\Tencent\TIM\Bin\TIM.exe
\nDeepin-Foxmail=c:\Program Files\Foxmail 7.2\Foxmail.exe
\nCMBChina=c:\windows\system32\PersonalBankPortal.exe
\napps.com.qq.im=c:\Program Files\Tencent\QQ\Bin\QQ.exe
\nDeepin-ThunderSpeed=c:\\Program Files\\Thunder Network\\Thunder\\Program\\Thunder.exe
\nDeepin-WeChat=c:\\Program Files\\Tencent\\WeChat\\WeChat.exe"

if [[ -n "$1" && -n "$2" ]]; then
    BOTTLE_NAME="$1"
    DEBUG_MSG="$2"
fi

APP_PATH="$(echo -e $APP_PATH_MAP | grep ${BOTTLE_NAME}=)"
if [ -n "$APP_PATH" ]; then
    mkdir $HOME/log &> /dev/null
    if [ -n "$3" ]; then
        #echo "CX_LOG="$HOME/log/${BOTTLE_NAME}.log" CX_DEBUGMSG="${DEBUG_MSG}" /opt/cxoffice/bin/wine --bottle ${BOTTLE_NAME} -- ${APP_PATH##*=} &"
        CX_LOG="$HOME/log/${BOTTLE_NAME}.log" CX_DEBUGMSG="${DEBUG_MSG}" /opt/cxoffice/bin/wine --bottle ${BOTTLE_NAME} -- "${APP_PATH##*=}" &
    else
        #echo "WINEPREFIX=${HOME}/.deepinwine/${BOTTLE_NAME} WINEDEBUG=${DEBUG_MSG} deepin-wine ${APP_PATH##*=} &> $HOME/log/${BOTTLE_NAME}.log &"
        WINEPREFIX=${HOME}/.deepinwine/${BOTTLE_NAME} WINEDEBUG=${DEBUG_MSG} deepin-wine "${APP_PATH##*=}" &> $HOME/log/${BOTTLE_NAME}.log &
    fi
    dde-file-manager $HOME/log &> /dev/null &
fi
