#!/bin/bash

APP_NAME="QQ"

get_bottle_path()
{
    PID_LIST=$(ps -ef | grep $1 | grep -E "C:|c:" |awk '{print $2}')
    PREFIX_LIST=""

    for pid_var in $PID_LIST ; do
        WINE_PREFIX=$(xargs -0 printf '%s\n' < /proc/$pid_var/environ | grep WINEPREFIX)
        WINE_PREFIX=${WINE_PREFIX##*=}
        #echo "found $pid_var : $WINE_PREFIX"
        for path in $(echo -e $PREFIX_LIST) ; do
            if [[ $path == "$WINE_PREFIX" ]]; then
                WINE_PREFIX=""
            fi
        done
        PREFIX_LIST+="\n$WINE_PREFIX"
    done
    echo -e $PREFIX_LIST | grep $HOME
}

if [ -n "$1" ]; then
    APP_NAME="$1"
fi

for path in $(get_bottle_path $APP_NAME); do
    if [[ $path == *"deepinwine"* ]]; then
        echo "kill ${path##*/} deepinwine"
        env WINEPREFIX="$path" /usr/lib/i386-linux-gnu/deepin-wine/wineserver -k
    elif [[ $path == *"cxoffice"* ]]; then
        echo "kill ${path##*/} cxoffice"
        env WINEPREFIX="$path" /opt/cxoffice/bin/wineserver -k
    else
        echo "unkown ${path}"
    fi
done
