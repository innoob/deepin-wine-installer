#!/bin/bash

get_bottle_path()
{
    PID_LIST=$(ps -ef | grep "${1}.exe" | grep "C:" |awk '{print $2}')
    PREFIX_LIST=""

    for pid_var in $PID_LIST ; do
        WINE_PREFIX=$(xargs -0 printf '%s\n' < /proc/$pid_var/environ | grep WINEPREFIX)
        WINE_PREFIX=${WINE_PREFIX##*=}
        #echo "found $pid_var : $WINE_PREFIX"
        for path in $(echo -e $PREFIX_LIST) ; do
            if [[ $path == "$WINE_PREFIX" ]]; then
                WINE_PREFIX=""
            fi
        done
        PREFIX_LIST+="\n$WINE_PREFIX"
    done
    echo -e $PREFIX_LIST | grep $HOME
}

send_to_process()
{
    for path in $(get_bottle_path $1); do
        if [[ $path == *"deepinwine"* ]]; then
            echo "send ${path##*/} deepinwine"
            env WINEPREFIX="$path" deepin-wine "/opt/deepinwine/tools/sendkeys.exe" $2
        elif [[ $path == *"cxoffice"* ]]; then
            echo "send ${path##*/} cxoffice"
            /opt/cxoffice/bin/wine --bottle=${path##*/} "/opt/deepinwine/tools/sendkeys.exe" $2
        else
            echo "unkown ${path}"
            env WINEPREFIX="$path" wine "/opt/deepinwine/tools/sendkeys.exe" $2
        fi
    done
}

send_to_process QQ $1
send_to_process TIM $1
